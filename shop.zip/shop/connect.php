<?php
/*
 * set var
 */
$cfHost = "localhost";
$cfUser = "root";
$cfPassword = "";
$cfDatabase = "dbmy";
 
/*
 * connection mysql
 */
$con = mysqli_connect($cfHost, $cfUser, $cfPassword,$cfDatabase) or die("Error conncetion mysql...");
$con->query("SET NAMES UTF8");
?>