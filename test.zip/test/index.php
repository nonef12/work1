<?php
    include 'connect.php';
    if (isset($_POST['submit']))
    {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $con=mysqli_connect('localhost', 'root', '', 'php-it.4-1-2565') or die ("ไม่สามารถเชื่อมต่อ Databases ได้");
        $result=$con->query("SELECT * FROM user WHERE username='$username' AND password='$password'");
        $num=mysqli_num_rows($result);
        $row=mysqli_fetch_array($result);
        /*$row=mysqli_fetch_array($result);
        if ($username==$row['username'] and $password==$row['password'])
        {
            echo "ยินดีด้วย! คุณล็อคอินผ่าน";
        }
        else
        {
            echo "กรุณาลองใหม่อีกครั้ง";
        }
        */
        if ($num==0)
        {
            echo "<script>alert('Invalid Username OR Password')</script>"; //หรือใช้ sweet alert ก็ได้
        }

        else 
        {
            session_start();
            $_SESSION['username']=$row['username'];
            $_SESSION['name']=$row['name'];
            header('location:Admin');
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>
<body>
    <div class="container w-25 mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white">Login</div>
            <div class="card-body">
                <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
                    <div class="mb-3">
                        <label for="" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>
                    <button type="submit" class="btn btn-primary" name="submit">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>