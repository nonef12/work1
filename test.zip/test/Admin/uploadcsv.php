<?php
    $filename=$_FILES['csv_file']['name'];
    if($filename != ""){
    move_uploaded_file($_FILES['csv_file']['tmp_name'],'csv/'.$filename);
    $data=fopen('csv/'.$filename,"r");
    while($row=fgetcsv($data,1000,",")){
        $username=$row[0];
        $password=$row[1];
        $name=$row[2];
        $email=$row[3];
        include '../connect.php';
        $sql="INSERT INTO user(username,password,name,email) VALUES('$username','$password','$name','$email')";
        $result=$con->query($sql);
    }
    fclose($data);
    header('location:user.php');
    }else{
        echo "<script>alert('ไม่มีไฟล์');window.history.back();</script>";
    }
?>