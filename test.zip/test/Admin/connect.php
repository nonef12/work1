<?php
    $host="localhost";
    $user="root";
    $password="";
    $dbname="php-it.4-1-2565";
    $con=mysqli_connect($host, $user, $password, $dbname) or die ("ไม่สามารถเชื่อมต่อ Databases ได้");
    $con->query("SET NAMES UTF8");
?>