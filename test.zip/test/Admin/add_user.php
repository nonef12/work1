<?php
    include 'navbar.php';
    include '../connect.php';
    if (isset($_POST['add']))
    {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $name=$_POST['name'];
        $email=$_POST['email'];
        $filename=$_FILES['user_pic']['name'];

        if ($username=='' || $password=='' || $name=='' || $email=='' || $filename=='')
        {
            echo "<script>alert('คุณยังไม่ได้กรอกข้อมูลหรือกรอกข้อมูลไม่ครบ')</script>";
        }
        else
        {
            $old_data=$con->query("SELECT username FROM user WHERE username='$username'");
            $num=mysqli_num_rows($old_data);
            if ($num > 0)
            {
                echo "<script>alert('Username นี้มีอยู่แล้ว')</script>";
            }
            else
            {
        /*$sql="INSERT INTO user (username, password, name, email) 
        VALUES('$username', '$password', '$name', '$email')"; แบบยาว*/
        if(move_uploaded_file($_FILES['user_pic']['tmp_name'],'user_img/'.$filename)){
        
            $sql="INSERT INTO user VALUES('$username', '$password', '$name', '$email', '$filename')"; //แบบสั้น
        $result=$con->query($sql);
        if (!$result){
            echo "<script>alert('ไม่สามารถเพิ่มข้อมูลได้')</script>";
        }else{
            echo "<script>window.location.href='user.php'</script>";
                    }
                }
            }
        }   
    }
?>
<div class="container w-50 mt-5">
    <div class="card">
        <div class="card-header bg-primary text-white">เพิ่มข้อมูล User</div>
        <div class="card-body">
    <form action="<?php $_SERVER['PHP_SELF']?>" method="POST" enctype="multipart/form-data">
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">Username</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="username">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="password">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">Name</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="name">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
            <input type="email" class="form-control" name="email">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">รูปภาพ</label>
        <div class="col-sm-10">
            <input type="file" class="form-control" name="user_pic">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label"></label>
        <div class="col-sm-10">
            <input type="submit" class="btn btn-success" name="add" value="เพิ่มข้อมูล">
        </div>
    </div>
    </form>
</div>
</div>
</div>