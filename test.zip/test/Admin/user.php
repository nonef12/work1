<?php
    include 'navbar.php';
?>
<div class="container w-75 mt-5">
    <div class="row">
    <div class="col-4">
        <a href="add_user.php" class="btn btn-success mb-3">เพิ่มข้อมูล</a>
    </div>
    <div class="col-8">
    <form action="uploadcsv.php" class="row" method="POST" enctype="multipart/form-data">
                <label class="col-form-label col-4">เพิ่มข้อมูลทีละหลายคน</label>
                <div class="col-4">
                    <input type="file" name="csv_file" class="form-control">
                </div>
                <div class="col-2">
                    <input type="submit" value="อัพโหลด" class="btn btn-primary">
                </div>
            </form>
    </div>
    </div>
    <table class="table table-striped">
        <tr class="bg-primary">
            <th class="text-white">ลำดับที่</th>
            <th class="text-white">ชื่อ - นามสกุล</th>
            <th class="text-white">Username</th>
            <th class="text-white">Email</th>
            <th class="text-white">รูปภาพ</th>
            <th class="text-white">จัดการ</th>
    </tr>
    <?php
        include '../connect.php';
        $sql="SELECT * FROM user";
        //$result=mysqli_query($con, $sql);  เขียนเต็มรูปแบบ
        $result=$con->query($sql); //เขียนแบบย่อ
        $i=1;
        while ($row=mysqli_fetch_array($result))
        {
    ?>
        <tr>
            <td><?php echo $i ?></td>
            <td><?php echo $row['name']?></td>
            <td><?php echo $row['username']?></td>
            <td><?php echo $row['email']?></td>
            <td>
                <img src="user_img/<?php echo $row['user_img']?>" width="100">
            </td>
            <td>
                <a href="edit_user.php?username=<?php echo $row['username']?>" class="btn btn-success mb-3">แก้ไข</a>  
                <a href="del_user.php?username=<?php echo $row['username']?>" class="btn btn-success mb-3"
                onclick="return confirm('ยืนยันการลบ?')">ลบ</a>
            </td>
            </tr>
        <?php
            $i++;
            }
        ?>
    </table>
</div>