<?php
    $filename=$_FILES['csv_file']['name'];
    if($filename != ""){
    move_uploaded_file($_FILES['csv_file']['tmp_name'],'csv/'.$filename);
    $data=fopen('csv/'.$filename,"r");
    while($row=fgetcsv($data,1000,",")){
        $pro_id=$row[0];
        $pro_name=$row[1];
        $pro_price=$row[2];
        $pro_qty=$row[3];
        include '../connect.php';
        $sql="INSERT INTO product(pro_id,pro_name,pro_price,pro_qty) VALUES('$pro_id','$pro_name','$pro_price','$pro_qty')";
        $result=$con->query($sql);
    }
    fclose($data);
    header('location:product.php');
    }else{
        echo "<script>alert('ไม่มีไฟล์');window.history.back();</script>";
    }
?>