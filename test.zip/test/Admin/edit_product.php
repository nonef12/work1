<?php
    include 'navbar.php';
    include '../connect.php';
    $pro_id=$_GET['pro_id'];
    $sql="SELECT * FROM product WHERE pro_id='$pro_id'";
    $result=$con->query($sql);
    $row=mysqli_fetch_array($result);

            if(isset($_POST['edit-pro'])){
                $pro_id=$_POST['pro_id'];
                $pro_name=$_POST['pro_name'];
                $pro_price=$_POST['pro_price'];
                $pro_qty=$_POST['pro_qty'];
                if($pro_id=='' || $pro_name=='' || $pro_price==''|| $pro_qty==''){
                    echo "<script>alert('คุณยังไม่ได้กรอกข้อมูลหรือกรอกข้อมูลไม่ครบ')</script>";
                }else{
                        $sql="UPDATE product SET pro_id='$pro_id',pro_name='$pro_name', pro_price='$pro_price', pro_qty='$pro_qty' WHERE pro_id='$pro_id'";
                        $result=$con->query($sql);
                        if(!$result){
                            echo "<script>alert('ไม่สามารถแก้ไขข้อมูลได้')</script>";
                        }else{
                            echo "<script>window.location.href='product.php'</script>";
                        }
                }  
            }
        
    
?>
<div class="container w-50 mt-5">
    <div class="card">
        <div class="card-header bg-primary text-white">แก้ไขข้อมูล Product</div>
        <div class="card-body">
    <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">รหัสสินค้า</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="pro_id" value="<?php echo $row['pro_id']?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">ชื่อสินค้า</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="pro_name" value="<?php echo $row['pro_name']?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">ราคาสินค้า</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="pro_price" value="<?php echo $row['pro_price']?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">จำนวนสินค้า</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="pro_qty" value="<?php echo $row['pro_qty']?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label"></label>
        <div class="col-sm-10">
            <input type="submit" class="btn btn-success" name="edit-pro" value="บันทึก">
        </div>
    </div>
    </form>
</div>
</div>
</div>