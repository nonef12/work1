<?php
    include 'navbar.php';
    include '../connect.php';
    if (isset($_POST['add']))
    {
        $pro_id=$_POST['pro_id'];
        $pro_name=$_POST['pro_name'];
        $pro_price=$_POST['pro_price'];
        $pro_qty=$_POST['pro_qty'];
        if ($pro_id=='' || $pro_name=='' || $pro_price=='' || $pro_qty=='')
        {
            echo "<script>alert('คุณยังไม่ได้กรอกข้อมูลหรือกรอกข้อมูลไม่ครบ')</script>";
        }
        
        else
        {
            $old_data=$con->query("SELECT pro_id FROM product WHERE pro_id='$pro_id'");
            $num=mysqli_num_rows($old_data);
            if ($num > 0)
            {
                echo "<script>alert('pro_id นี้มีอยู่แล้ว')</script>";
            }

            else
            {
        /*$sql="INSERT INTO user (username, password, name, email) 
        VALUES('$username', '$password', '$name', '$email')"; แบบยาว*/
        $sql="INSERT INTO product VALUES('$pro_id', '$pro_name', '$pro_price', '$pro_qty')"; //แบบสั้น
        $result=$con->query($sql);
        if (!$result)
        {
            echo "<script>alert('ไม่สามารถเพิ่มข้อมูลได้')</script>";
        }

        else
        {
            echo "<script>window.location.href='product.php'</script>";
        }
            }
        }   
    }
?>
<div class="container w-50 mt-5">
    <div class="card">
        <div class="card-header bg-primary text-white">เพิ่มข้อมูล Product</div>
        <div class="card-body">
    <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">รหัสสินค้า</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="pro_id">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">ชื่อสินค้า</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="pro_name">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">ราคาสินค้า</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="pro_price">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">จำนวนสินค้า</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="pro_qty">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label"></label>
        <div class="col-sm-10">
            <input type="submit" class="btn btn-success" name="add" value="เพิ่มข้อมูล">
        </div>
    </div>
    </form>
</div>
</div>
</div>