<?php
    include 'navbar.php';
?>
<div class="container w-75 mt-5">
    <div class="row">
    <div class="col-4">
    <a href="add_product.php" class="btn btn-success mb-3">เพิ่มข้อมูล</a>
    </div>
    <div class="col-8">
    <form action="uploadcsvpro.php" class="row" method="POST" enctype="multipart/form-data">
                <label class="col-form-label col-4">เพิ่มข้อมูลจำนวนมาก</label>
                <div class="col-4">
                    <input type="file" name="csv_file" class="form-control">
                </div>
                <div class="col-2">
                    <input type="submit" value="อัพโหลด" class="btn btn-primary">
                </div>
            </form>
    </div>
    </div>  
    <table class="table table-striped">
        <tr class="bg-primary">
            <th class="text-white">รหัสสินค้า</th>
            <th class="text-white">ชื่อสินค้า</th>
            <th class="text-white">ราคาสินค้า</th>
            <th class="text-white">จำนวนสินค้า</th>
            <th class="text-white">จัดการ</th>
    </tr>
    <?php
        include '../connect.php';
        $sql="SELECT * FROM product";
        //$result=mysqli_query($con, $sql);  เขียนเต็มรูปแบบ
        $result=$con->query($sql); //เขียนแบบย่อ
        $i=1;
        while ($row=mysqli_fetch_array($result))
        {
    ?>
        <tr>
            <td><?php echo $row['pro_id'] ?></td>
            <td><?php echo $row['pro_name']?></td>
            <td><?php echo $row['pro_price']?></td>
            <td><?php echo $row['pro_qty']?></td>
            <td>
                <a href="edit_product.php?pro_id=<?php echo $row['pro_id']?>" class="btn btn-success mb-3">แก้ไข</a>  
                <a href="del_product.php?pro_id=<?php echo $row['pro_id']?>" class="btn btn-success mb-3"
                onclick="return confirm('ยืนยันการลบ?')">ลบ</a>
            </td>
            </tr>
        <?php
            $i++;
            }
        ?>
    </table>
</div>