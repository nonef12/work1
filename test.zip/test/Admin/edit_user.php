<?php
    include 'navbar.php';
    include '../connect.php';
    $username=$_GET['username'];
    $sql="SELECT * FROM user WHERE username='$username'";
    $result=$con->query($sql);
    $row=mysqli_fetch_array($result);

            if(isset($_POST['edit'])){
                $password=$_POST['password'];
                $name=$_POST['name'];
                $email=$_POST['email'];
                $filename=$_FILES['user_img']['name'];
                $tmp_name=$_FILES['user_img']['tmp_name'];
                if($password=='' || $name=='' || $email==''){
                    echo "<script>alert('คุณยังไม่ได้กรอกข้อมูลหรือกรอกข้อมูลไม่ครบ')</script>";
                }else{
                    if($filename){
                    unlink('user_img/'.$row['user_img']);
                    move_uploaded_file($tmp_name,'user_img/'.$filename);
                        $sql="UPDATE user SET password='$password',name='$name',email='$email', user_img='$filename' WHERE username='$username'";
                        $result=$con->query($sql);
                    }else{
                        $sql="UPDATE user SET password='$password',name='$name',email='$email' WHERE username='$username'";
                        $result=$con->query($sql);
                    }
                        if(!$result){
                            echo "<script>alert('ไม่สามารถแก้ไขข้อมูลได้')</script>";
                        }else{
                            echo "<script>window.location.href='user.php'</script>";
                        }
                }  
            }
        
    
?>
<div class="container w-50 mt-5">
    <div class="card">
        <div class="card-header bg-primary text-white">แก้ไขข้อมูล User</div>
        <div class="card-body">
    <form action="<?php $_SERVER['PHP_SELF']?>" method="POST" enctype="multipart/form-data">
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">Username</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="username" value="<?php echo $row['username']?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="password" value="<?php echo $row['password']?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">Name</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="name" value="<?php echo $row['name']?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
            <input type="email" class="form-control" name="email" value="<?php echo $row['email']?>">
        </div>
    </div>
            <!-- รูปเดิม -->
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label"></label>
        <div class="col-sm-10">
        <img src="user_img/<?php echo $row['user_img']?>" width="100">
        </div>
    </div>


    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label">รูปภาพ</label>
        <div class="col-sm-10">
            <input type="file" class="form-control" name="user_img">
        </div>
    </div>
    <div class="mb-3 row">
        <label class="col-sm-2 col-form-label"></label>
        <div class="col-sm-10">
            <input type="submit" class="btn btn-success" name="edit" value="บันทึก">
        </div>
    </div>
    </form>
</div>
</div>
</div>